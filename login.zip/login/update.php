<?php

// php code to Update data from mysql database Table

if(isset($_POST['update']))
{
    
   $hostname = "localhost";
   $username = "root";
   $password = "";
   $databaseName = "login";
   
   $connect = mysqli_connect($hostname, $username, $password, $databaseName);
   
   // get values form input text and number
   
   $id = $_POST['id'];
   $fn = $_POST['fn'];
   $mn = $_POST['mn'];
   $ln = $_POST['ln'];
   $dob = $_POST['dob'];
   $addrs = $_POST['addrs'];
   $usrname = $_POST['usrname'];
   $email = $_POST['email'];
   $pwd = ($_POST['pwd']);
           
   // mysql query to Update data
   $query = "UPDATE `user` SET `memFname`='".$fn."',`memMname`='".$mn."',`memLname`='".$ln."',`memDOB`='".$dob."',`address`='".$addrs."',`username`='".$usrname."',`email`='".$email."',`password`='".$pwd."' WHERE `id` = $id";
   
   $result = mysqli_query($connect, $query);
   
   if($result)
   {
    echo "
  <style>
    div#failmsg {
        margin: auto;
        border: 1px solid green;
        border-radius: 5px;
        border-color: green;
        height: 25px;
        margin-bottom: 10px;
    }
    .text{
      text-align:center;
      padding:2px 20px;
      font-size: 12px;
      color: green;
    }
  </style>
    <div class='col-md-12'>
      <div class='col-md-5'>

      </div>
      <div class='col-md-2' id='failmsg'>
        <p class='text'>Data Updated</p>
      </div>
      <div class='col-md-5'>

      </div>
    </div>
    ";
   }else{
    echo "
  <style>
    div#failmsg {
        margin: auto;
        border: 1px solid red;
        border-radius: 5px;
        border-color: red;
        height: 25px;
        margin-bottom: 10px;
    }
    .text{
      text-align:center;
      padding:2px 20px;
      font-size: 12px;
      color: red;
    }
  </style>
    <div class='col-md-12'>
      <div class='col-md-5'>

      </div>
      <div class='col-md-2' id='failmsg'>
        <p class='text'>failed to update</p>
      </div>
      <div class='col-md-5'>

      </div>
    </div>
    ";
   }
   mysqli_close($connect);
}

?>

<!Doctype html>
<html>
<head>
	<title>Update Profile</title>
	
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" >

<link rel="stylesheet" type="text/css" href="css/reg.css">
<!-- Latest compiled and minified JavaScript -->

</head>
<body>
	<header>
			<a class="logout" href='logout.php'>Logout</a>
	</header>
<div class="container">
        <div class="row">
            <div class="col-md-6 col-md-offset-3">
                <div class="panel panel-login">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col-xs-12" id="register-header">
                                <center>UPDATE</center>
                            </div>
                        </div>
                        <hr>
                    </div>

                    <div class="panel-body">
                        <div class="row">
                            <div class="col-lg-12">
                                <form id="register-form" action="update.php" method="POST">
                                    <div class="form-group">
                                        <input type="text" name="fn" id="memFname" tabindex="1" class="col-md-4" placeholder="First name" value="" required>
                                        <input type="text" name="mn" id="memMname" tabindex="1" class="col-md-3" placeholder="Middle Name" value="" required>
                                        <input type="text" name="ln" id="memLname" tabindex="1" class="col-md-4" placeholder="Last name" value="" required>
                                    </div>
                                	<div class="form-group">
                                		<input type="tetx" name="id" class="form-control" placeholder="Your ID number" value="" required>
                                	</div>

                                    <div class="col-md-12">
	                                    <div class="form-group">
	                                            <label for="dob">Date of Birth:</label>
	                                            <input type="date" name="dob" id="memDOB" tabindex="1" class="form-control" value="" required>
	                                    </div>
                                    </div>
                                    <div class="form-group">
                                        <input type="text" name="addrs" id="address" tabindex="1" class="form-control" placeholder="Address" value="" required>
                                    </div>
                                    <div class="form-group">
                                        <input type="text" name="usrname" id="username" tabindex="1" class="form-control" placeholder="username" value="" required>
                                    </div>
                                    <div class="form-group">
                                        <input type="email" name="email" id="email" tabindex="1" class="form-control" placeholder="email" value="" required>
                                    </div>
                                    <div class="form-group">
                                        <input type="password" name="pwd" id="password" tabindex="2" class="form-control" placeholder="password" value="" required>
                                    </div>
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-sm-6 col-sm-offset-3">
                                            	<button type="submit" name="update" class="form-control btn btn-register">Update</button>
                                            </div>
                                        </div>
                                    </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</body>

</html>