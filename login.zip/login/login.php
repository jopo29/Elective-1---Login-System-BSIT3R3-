<?php  //Start the Session
session_start();
 require('connect.php');
//If the form is submitted or not.
//If the form is submitted
if (isset($_POST['username']) and isset($_POST['password'])){
//Assigning posted values to variables.
$username = $_POST['username'];
$password = ($_POST['password']);
//Checking the values are existing in the database or not
$query = "SELECT * FROM `user` WHERE username='$username' and password='$password'";
 
$result = mysqli_query($connection, $query) or die(mysqli_error($connection));
$count = mysqli_num_rows($result);
//If the posted values are equal to the database values, then session will be created for the user.
if ($count == 1){
$_SESSION['username'] = $username and $_SESSION['password'] = $password;
  header('Location: update.php');
}else{
//If the login credentials doesn't match, he will be shown with an error message.
  echo "
<style>
  div#failmsg {
      margin: auto;
      border: 1px solid red;
      border-radius: 5px;
      border-color: red;
      height: 25px;
      margin-bottom: 10px;
  }
  .text{
    text-align:center;
    padding:2px 20px;
    font-size: 12px;
    color: red;
  }
</style>
  <div class='col-md-12'>
    <div class='col-md-4'>

    </div>
    <div class='col-md-4' id='failmsg'>
      <p class='text'>Invalid Password/username</p>
    </div>
    <div class='col-md-5'>

    </div>
  </div>
  ";
}
}
//if the user is logged in Greets the user with message

//When the user visits the page first time, simple login form will be displayed.
?>
<html>
<head>
	<title>User Login Using PHP & MySQL</title>
<link rel="stylesheet" type="text/css" href="css/animate.css">
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" >

<link rel="stylesheet" type="text/css" href="css/login.css">

<!-- Latest compiled and minified JavaScript -->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<div class="container">
      <div class="row">
      <div class="col-md-6 col-md-offset-3">
        <div class="panel panel-login">
          <div class="panel-heading">
            <div class="row">
                <div class="col-xs-12" id="login-header">
                    <center>Login</center>
                </div>
            </div>
            <hr>
          </div>
          <div class="panel-body">
            <div class="row">
              <div class="col-lg-12">
                <form id="login-form" method="POST">
                  <div class="form-group">
                    <input type="text" name="username" id="username" tabindex="1" class="form-control" placeholder="Username" value="" required>
                  </div>
                  <div class="form-group">
                    <input type="password" name="password" id="password" tabindex="2" class="form-control" placeholder="Password" required>
                  </div>
                  <div class="form-group text-center">
                    <input type="checkbox" tabindex="3" class="" name="remember" id="remember">
                    <label for="remember"> Remember Me</label>
                  </div>
                  <div class="form-group">
                    <div class="row">
                      <div class="col-sm-6 col-sm-offset-3">
                        <input type="submit" name="login-submit" id="login-submit" tabindex="4" class="form-control btn btn-login" value="Log In">
                      </div>
                    </div>
                  </div>
                  <div class="col-md-12">
                      <p>Don't have an account? Register here<a class="registerpagebtn" href="register.php" type="button">&nbsp;<u>Register here<u></a></p>
                  </div>                  
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</body>

</html>