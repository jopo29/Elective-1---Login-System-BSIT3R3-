<?php
	require('connect.php');
    // If the values are posted, insert them into the database.
    if (isset($_POST['username']) && isset($_POST['password'])){
        $memFname = $_POST['memFname'];
        $memMname = $_POST['memMname'];
        $memLname = $_POST['memLname'];
        $memDOB = $_POST['memDOB'];
        $address = $_POST['address'];        
        $username = $_POST['username'];
	    $email = $_POST['email'];
        $password = ($_POST['password']);
        $passwordagain = ($_POST['passwordagain']);
        if($password == $passwordagain){
            $query = "INSERT INTO `user` (username, password, email, memFname, memMname, memLname, memDOB, address) VALUES ('$username', '$password', '$email', '$memFname', '$memMname', '$memLname', '$memDOB', '$address')";
            $result = mysqli_query($connection, $query);
            if($result){
                  echo "
                <style>
                  div#failmsg {
                      margin: auto;
                      border: 1px solid green;
                      border-radius: 5px;
                      border-color: green;
                      height: 25px;
                      margin-bottom: 10px;
                  }
                  .text{
                    text-align:center;
                    padding:2px 20px;
                    font-size: 12px;
                    color: green;
                  }
                </style>
                  <div class='col-md-12'>
                    <div class='col-md-5'>

                    </div>
                    <div class='col-md-2' id='failmsg'>
                      <p class='text'>User Created Successfully</p>
                    </div>
                    <div class='col-md-5'>

                    </div>
                  </div>
                  ";
            }else{ 
                  echo "
                <style>
                  div#failmsg {
                      margin: auto;
                      border: 1px solid red;
                      border-radius: 5px;
                      border-color: red;
                      height: 25px;
                      margin-bottom: 10px;
                  }
                  .text{
                    text-align:center;
                    padding:2px 20px;
                    font-size: 12px;
                    color: red;
                  }
                </style>
                  <div class='col-md-12'>
                    <div class='col-md-5'>

                    </div>
                    <div class='col-md-2' id='failmsg'>
                      <p class='text'>User Registration Failed Username already exist!</p>
                    </div>
                    <div class='col-md-5'>

                    </div>
                  </div>
                  ";

            }            
        }else{
              echo "
            <style>
              div#failmsg {
                  margin: auto;
                  border: 1px solid red;
                  border-radius: 5px;
                  border-color: red;
                  height: 25px;
                  margin-bottom: 10px;
              }
              .text{
                text-align:center;
                padding:2px 20px;
                font-size: 12px;
                color: red;
              }
            </style>
              <div class='col-md-12'>
                <div class='col-md-5'>

                </div>
                <div class='col-md-2' id='failmsg'>
                  <p class='text'>Password does not match</p>
                </div>
                <div class='col-md-5'>

                </div>
              </div>
              ";
        }

    }
    ?>
<html>
<head>
	<title>User Registeration</title>
<link rel="stylesheet" type="text/css" href="css/animate.css">
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" >

<link rel="stylesheet" type="text/css" href="css/reg.css">
<!-- Latest compiled and minified JavaScript -->

</head>
<body>
	<header>
	</header>
<div class="container">
        <div class="row">
            <div class="col-md-6 col-md-offset-3">
                <div class="panel panel-login">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col-xs-12" id="register-header">
                                <center>Register</center>
                            </div>
                        </div>
                        <hr>
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-lg-12">
                                <form id="register-form" method="POST">
                                    <div id="name" class="form-group">
                                        <input type="text" name="memFname" id="memFname" tabindex="1" class="col-md-4" placeholder="First Name" value="" required>
                                        <input type="text" name="memMname" id="memMname" tabindex="1" class="col-md-3" placeholder="Middle Name" value="" required>
                                        <input type="text" name="memLname" id="memLname" tabindex="1" class="col-md-4" placeholder="Last Name" value="" required>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="col-md-3">
                                            <h5>Date of Birth:</h5>
                                        </div>
                                        <div class="col-md-6">
                                            <input type="date" name="memDOB" id="memDOB" tabindex="1" class="form-control" value="" required>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <input type="text" name="address" id="address" tabindex="1" class="form-control" placeholder="Address" value="" required>
                                    </div>
                                    <div class="form-group">
                                        <input type="text" name="username" id="username" tabindex="1" class="form-control" placeholder="Username" value="" required>
                                    </div>
                                    <div class="form-group">
                                        <input type="email" name="email" id="email" tabindex="1" class="form-control" placeholder="Email Address" value="" required>
                                    </div>
                                    <div class="form-group">
                                        <input type="password" name="password" id="password" tabindex="2" class="form-control" placeholder="Password" required>
                                    </div>
                                    <div class="form-group">
                                        <input type="password" name="passwordagain" id="passwordagain" tabindex="2" class="form-control" placeholder="Confirm Password" required>
                                    </div>
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-sm-6 col-sm-offset-3">
                                                <input type="submit" name="register-submit" id="register-submit" tabindex="4" class="form-control btn btn-register" value="Register Now">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <p>Already have an account? login here  <a class="loginpagebtn" href="login.php" type="button">&nbsp;<u>Login here<u></a></p>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</body>

</html>